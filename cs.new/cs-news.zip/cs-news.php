<?php
/**
 * Plugin Name: CS News Manager
 * Description: ระบบจัดการข่าวประชาสัมพันธ์เฉพาะหลังบ้าน พร้อมฟอร์มเพิ่ม/แก้ไข/ลบ และตารางรายการข่าว
 * Version: 1.0
 * Author: ChatGPT
 */

if (!defined('ABSPATH')) exit;

/* -----------------------------
   1) Register Custom Post Type (Admin Only)
------------------------------ */
add_action('init', function () {
    register_post_type('cs_news', [
        'label'         => 'ข่าวประชาสัมพันธ์',
        'public'        => false,
        'show_ui'       => false, // เราจะสร้าง UI เอง
        'supports'      => ['title', 'editor'],
    ]);
});


/* -----------------------------
   2) Create Admin Menu
------------------------------ */
add_action('admin_menu', function () {
    add_menu_page(
        'จัดการข่าวประชาสัมพันธ์',
        'ข่าวประชาสัมพันธ์',
        'manage_options',
        'cs-news',
        'cs_news_page',
        'dashicons-megaphone',
        25
    );
});


/* -----------------------------
   3) Handle Create / Update / Delete
------------------------------ */
add_action('admin_init', function () {

    // Save or Update
    if (isset($_POST['cs_news_save'])) {

        $data = [
            'post_title'   => sanitize_text_field($_POST['title']),
            'post_content' => wp_kses_post($_POST['content']),
            'post_type'    => 'cs_news',
            'post_status'  => 'publish'
        ];

        // Update news
        if (!empty($_POST['news_id'])) {
            $data['ID'] = intval($_POST['news_id']);
            wp_update_post($data);
            wp_redirect(admin_url('admin.php?page=cs-news&updated=1'));
            exit;
        }

        // Insert new news
        wp_insert_post($data);
        wp_redirect(admin_url('admin.php?page=cs-news&created=1'));
        exit;
    }

    // Delete news
    if (isset($_GET['delete_news'])) {
        wp_delete_post(intval($_GET['delete_news']), true);
        wp_redirect(admin_url('admin.php?page=cs-news&deleted=1'));
        exit;
    }
});


/* -----------------------------
   4) Admin Page UI
------------------------------ */
function cs_news_page()
{
    $edit_mode = false;
    $edit_post = null;

    // If editing
    if (isset($_GET['edit_news'])) {
        $edit_mode = true;
        $edit_post = get_post(intval($_GET['edit_news']));
    }

    ?>
    <div class="wrap">
        <h1>จัดการข่าวประชาสัมพันธ์</h1>

        <?php if (isset($_GET['created'])) echo '<div class="updated"><p>เพิ่มข่าวเรียบร้อย</p></div>'; ?>
        <?php if (isset($_GET['updated'])) echo '<div class="updated"><p>แก้ไขข่าวเรียบร้อย</p></div>'; ?>
        <?php if (isset($_GET['deleted'])) echo '<div class="updated"><p>ลบข่าวเรียบร้อย</p></div>'; ?>

        <h2><?php echo $edit_mode ? 'แก้ไขข่าว' : 'เพิ่มข่าวใหม่'; ?></h2>

        <form method="post">
            <table class="form-table">
                <tr>
                    <th>หัวข้อข่าว</th>
                    <td>
                        <input type="text" name="title" class="regular-text"
                               value="<?php echo $edit_mode ? esc_attr($edit_post->post_title) : ''; ?>" required>
                    </td>
                </tr>

                <tr>
                    <th>รายละเอียด</th>
                    <td>
                        <?php
                        wp_editor(
                            $edit_mode ? $edit_post->post_content : '',
                            'content',
                            ['textarea_name' => 'content', 'textarea_rows' => 5]
                        );
                        ?>
                    </td>
                </tr>
            </table>

            <?php if ($edit_mode): ?>
                <input type="hidden" name="news_id" value="<?php echo $edit_post->ID; ?>">
            <?php endif; ?>

            <p>
                <button type="submit" name="cs_news_save" class="button button-primary">
                    <?php echo $edit_mode ? 'อัปเดตข่าว' : 'บันทึกข่าว'; ?>
                </button>

                <?php if ($edit_mode): ?>
                    <a href="admin.php?page=cs-news" class="button">ยกเลิก</a>
                <?php endif; ?>
            </p>
        </form>

        <hr>

        <h2>รายการข่าวทั้งหมด</h2>

        <table class="widefat striped">
            <thead>
            <tr>
                <th>หัวข้อ</th>
                <th>วันที่</th>
                <th width="120">การจัดการ</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $news = get_posts([
                'post_type' => 'cs_news',
                'numberposts' => -1,
                'orderby' => 'date',
                'order' => 'DESC'
            ]);

            if ($news):
                foreach ($news as $item):
                    ?>
                    <tr>
                        <td><?php echo esc_html($item->post_title); ?></td>
                        <td><?php echo esc_html($item->post_date); ?></td>
                        <td>
                            <a class="button" href="admin.php?page=cs-news&edit_news=<?php echo $item->ID; ?>">แก้ไข</a>
                            <a class="button" style="color:red"
                               onclick="return confirm('ยืนยันการลบ?');"
                               href="admin.php?page=cs-news&delete_news=<?php echo $item->ID; ?>">ลบ</a>
                        </td>
                    </tr>
                <?php
                endforeach;
            else:
                echo '<tr><td colspan="3">ยังไม่มีข่าว</td></tr>';
            endif;
            ?>
            </tbody>
        </table>

    </div>
    <?php
}
